create table dimDate (
currentDate Date PRIMARY KEY,
dayNum INT,
dayName VARCHAR(100),
monthNum INT,
monthName VARCHAR(50),
quarter INT,
year int

);
DROP TABLE dimDate;

--procedure for date

USE MarketingDW
GO

CREATE PROCEDURE usp_generate_dimDate @Start_Date datetime,@End_Date datetime  AS
truncate table  dimDate

declare @Current_Date datetime
set @Current_Date = @Start_Date

while ( @Current_Date <= @End_Date)
begin
  insert dimDate values(
@Current_Date,
DATEPART(DAY,@Current_Date),
DATEPART(WEEKDAY,@Current_Date),
DATEPART(MONTH,@Current_Date),
DATEPART(MONTH,@Current_Date),
DATEPART(QUARTER,@Current_Date),
DATEPART(YEAR,@Current_Date)
)
set @Current_Date = DATEADD(day,1,@Current_Date)

end

go



EXEC usp_generate_dimDate '1/1/2010','4/7/2020'

GO



