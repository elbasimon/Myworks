create table dimProduct (
	productKey INT PRIMARY KEY IDENTITY(1,1),
	productID INT,
	productName VARCHAR(255),
	unitPrice DECIMAL(9,2),
	productSold INT,
	totalSale DECIMAL(9,2)
	);

DROP TABLE dimProduct;

truncate table dimProduct;

create table dimDepartment (
	departmentKey INT PRIMARY KEY IDENTITY(1,1),
	departmentID INT,
	departmentName VARCHAR(50)
);

DROP TABLE dimDepartment;

create table dimEmployee (
	employeeKey INT PRIMARY KEY IDENTITY(1,1),
	employeeID INT,
	fullName VARCHAR(100),
	dateOfJoining DATE,
	reportsTo INT,
	position VARCHAR(50),
	employeeType VARCHAR(50),
	gender VARCHAR(20),
	lengthOfService DECIMAL(3,2),
);

DROP TABLE dimEmployee;

create table factPromotion (
	promotionKey INT PRIMARY KEY IDENTITY(1,1),
	promotionID INT,
	marketingDetailKey INT,
	productKey INT,
	employeeKey INT,
	totalPromotionCost DECIMAL(5,2),
	empHourlyRate DECIMAL(5,2),
	campaignHours DECIMAL(9,2)
);

DROP TABLE factPromotion;

create table dimMarketingType (
	marketingKey INT PRIMARY KEY IDENTITY(1,1),
	marketingID INT,
	marketingTypeName VARCHAR(50),
	marketingDescription VARCHAR(50),
);

DROP TABLE dimMarketingType;

