/*Author: Elba Simon 19480171

 *Pledge of honour: I pledge by honour that this program is solely my work.

 *Description: This program  asks the user to enter two lines of comma-separated numbers and count the total number of overlapping numbers between the two lines. 
 */

package jassignment;

import  java.util.Scanner;

public class Main {

	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		System.out.println("Enter the first line of numbers: ");

		String string1;

		string1 = (input.nextLine());

		String[] strs1 = string1.split(",");

		String string2;

		System.out.println("Enter the second line of numbers: ");

		string2 = (input.nextLine());

		String[] strs2 = string2.split(","); 

		int size1 = strs1.length;

		double[] array1 = new double[size1]; //Initialize double array

		for (int i=0;i<size1;i++) 

		{

			array1[i]=Double.parseDouble(strs1[i]); 

		}


		int size2 = strs2.length;

		double[] array2 = new double[size2]; 

		for (int i=0;i<size2;i++) 

		{

			array2[i]=Double.parseDouble(strs2[i]); 

		}

		int count = 0;

		for(double e1 : array1) { //comparing arrays.

			for(double e2 : array2) {

				if(e1 == e2) {

					count ++;
				}
			}
		}

		System.out.printf("Number of overlapping numbers is %d", count);
	}

}
