/*Author: Elba Simon 19480171

*Pledge of honour: I pledge by honour that this program is solely my work.

*Description: This program finds the area and perimeter of a rectangle of given height and width.
*/


package jassignment;

import  java.util.Scanner; 

public class Main {

	public static void main(String[] args) {

		double height;
		double width;
		double Area;
		double Perimeter;


		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the height of the rectangle: ");
		height = sc.nextDouble();
		System.out.println("Enter the width of the rectangle: ");
		width = sc.nextDouble();
		sc.close();

		Area= height * width;
		Perimeter = 2 * (height + width);

		System.out.printf("%-20s%-20s%-20s%-20s\n","Height","Width","Area","Perimeter");
		String spaceline = String.format("%-35s", "");
		String dashline = spaceline.replace("", "-");
		System.out.println(dashline);
		System.out.printf("%-10.2f", + height);
		System.out.printf("%15.2f", + width);
		System.out.printf("%20.2f", + Area);
		System.out.printf("%22.2f", + Perimeter);
	}

}
