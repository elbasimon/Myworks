/*Author: Elba Simon 19480171

*Pledge of honour: I pledge by honour that this program is solely my work.

*Description: This program prints a message for the given card letter.
*/

package jassignment;

import  java.util.Scanner;

public class Main {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {

		String input;
		int i = 0;
		do {

			System.out.println("Enter card letter(j/q/k/a): ");
			input = sc.nextLine();
			if(input.equalsIgnoreCase("a")) { //accepts input in upper and lower cases.
				i = 1;
				System.out.println("It's an Ace");
			}

			else if(input.equalsIgnoreCase("j")) {
				i = 1;
				System.out.println("It's an Jack");
			}

			else if(input.equalsIgnoreCase("q")) {
				i = 1;
				System.out.println("It's an Queen");
			}

			else if(input.equalsIgnoreCase("k")) {
				i = 1;
				System.out.println("It's an King");
			}

			else {
				System.out.println("Invalid, try again");
			}


		}while(i == 0);

	}

}
