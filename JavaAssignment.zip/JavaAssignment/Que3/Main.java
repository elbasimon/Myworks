/*Author: Elba Simon 19480171

 *Pledge of honour: I pledge by honour that this program is solely my work.

 *Description: This program prints a message for the month based on the input number.
 */


package jassignment;

import  java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		int month;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number from 1-12: ");
		month= sc.nextInt();

		if((month == 1) || (month == 2) || (month == 12))
		{
			System.out.println("Wonderful Summer");

		}

		if((month == 3) || (month == 4) || (month == 5))
		{
			System.out.println("Colourful Autumn");
		}

		if((month == 6) || (month == 7) || (month == 8))
		{
			System.out.println("Freezing winter");
		}

		if((month == 9) || (month == 10) || (month == 11 ))
		{
			System.out.println("Amazing Spring");

		}

		if((month < 1) || (month > 12))
		{
			System.out.println("Invalid Season");

		}
		sc.close();

	}

}
