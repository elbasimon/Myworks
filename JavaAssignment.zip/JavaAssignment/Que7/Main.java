/*Author: Elba Simon 19480171

 *Pledge of honour: I pledge by honour that this program is solely my work.

 *Description: This program simulate the data collecting process by requesting a series of stock prices to be entered by the user. 
 */


package assignment1;

import java.util.*;

public class Main {

	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		int size, i,count = 0;
		double value;
		System.out.println("How many stocks? ");
		size = Integer.parseInt(sc.nextLine());
		double[] arraystock = new double[size];
		for (i = 0; i < arraystock.length; i++) {

			System.out.printf("Enter price for stock #%d: \n", i+1);
			arraystock[i] = Double.parseDouble(sc.nextLine());
		}

		double sum = 0; //to calculate the sum of array elements.
		for (i = 0; i < arraystock.length; i++) {

			sum = sum + arraystock[i];
		}

		double avg = sum/size; //to calculate the average of price.
		System.out.printf("Average price: %.02f\n", + avg);

		double max = 0;
		max = arraystock[0];
		for (i = 0; i < arraystock.length; i++) { //to find the highest stock price.

			if(arraystock[i]> max) {
				max = arraystock[i];
			}
		}

		System.out.printf("Maximum price: %.02f\n", max);

		for (i = 0; i < arraystock.length; i++) {
			value = arraystock[i];
			if((value >= 1.5) && (value <= 5.5)){
				count ++;
			}

		}

		System.out.printf("Stocks priced between $1.5 and $5.5: %d\n", count);

		boolean flag = false;
		do {
			System.out.printf("Enter stock number (1-%d): ",size);
			int stock = Integer.parseInt(sc.nextLine());
			if((stock < 1) || stock > size) {
				System.out.println("Stock doesn�t exist. Enter again.");
			}

			else {
				int n = stock - 1;
				double stockprice = arraystock[n];
				System.out.printf("Price for stock #%d: $%.02f",stock,stockprice);
				flag = true;
			}

		}while(!flag);
	} 


}
