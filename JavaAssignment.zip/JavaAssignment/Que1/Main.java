/*Author: Elba Simon 19480171

*Pledge of honour: I pledge by honour that this program is solely my work.

*Description: This program prints a single backslash,a double backslash,a pair of single quote,a pair of double quote.
*/


package jassignment;

import static java.lang.System.out; 

public class Main {

	public static void main(String[] args) {
		
		out.printf("%-30s%-30s\n", "Escape Sequence","Description"); 
    	//generate a dash line
    	String spaceline = String.format("%25s", "");
    	String dashline = spaceline.replace("", "-");
    	out.println(dashline);
    	out.printf("%-30s%-30s\n","\\","A single backslash" );
    	out.printf("%-30s%-30s\n","\\\\","A double backslash" );
    	out.printf("%-30s%-30s\n","\'\'","A pair of single quote" );
    	out.printf("%-30s%-30s\n","\"\"","A pair of double quote" );
	}

}
