/*Author: Elba Simon 19480171

 *Pledge of honour: I pledge by honour that this program is solely my work.

 *Description: This program asks the user to guess a computer generated secret number. 
 */

package jassignment;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;
import java.util.List;
import java.util.ArrayList;

public class Main {

	static Scanner input = new Scanner(System.in);

	public static void main(String[] args) {

		int num = ThreadLocalRandom.current().nextInt(1,11); //generate a random number.
		
		System.out.println("Enter comma-separated numbers to guess my secret number (1-10): ");
		String string1;
		string1 = (input.nextLine());
		String[] stringArray = string1.split(",");

		List<Integer> list = new ArrayList<>(stringArray.length); //creating the list.

		for (String s : stringArray) {
			list.add(Integer.valueOf(s));
		}
		int count = 0;
		for(int e1 : list ) {
			if(e1 == num) {
				count = 1;
			}
		}
		if(count == 1) {
			int pos =list.indexOf(num);
			System.out.printf("You won, The The %dth attempt in your numbers is my secret number.", pos + 1);
		}
		else 
			System.out.printf("You lost, My secret number is %d.", num);
	}

}
