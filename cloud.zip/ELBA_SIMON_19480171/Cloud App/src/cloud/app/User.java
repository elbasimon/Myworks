/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cloud.app;

/**
 *
 * @author ELBA
 */
class User {
    
    private int UserID;
    private String First_Name, Last_Name, UserName, Address, Password, Confirm_Password;
    
   public User(int UserID, String First_Name, String Last_Name, String UserName, String Address, String Password, String Confirm_Password){
       
       this.UserID=UserID;
       this.First_Name=First_Name;
       this.Last_Name=Last_Name;
       this.UserName=UserName;
       this.Address=Address;
       this.Password=Password;
       this.Confirm_Password=Confirm_Password;
   }
    public int getUserID(){
        return UserID;
    }
    public String getFirst_Name(){
        return First_Name;
    }
    public String getLast_Name(){
        return Last_Name;
    }
    public String getUserName(){
        return UserName;
    }
    public String getAddress(){
        return Address;
    }
    public String getPassword(){
        return Password;
    }
    public String getConfirm_Password(){
        return Confirm_Password;
    }
    
}