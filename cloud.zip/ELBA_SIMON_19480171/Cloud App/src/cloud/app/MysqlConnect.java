/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cloud.app;
import java.sql.*;
import javax.swing.*;

/**
 *
 * @author ELBA
 */
public class MysqlConnect {
    
    Connection conn =null;
    public static Connection ConnectDB(){
        
    try{
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        Connection conn = DriverManager.getConnection("jdbc:sqlserver://LAPTOP-AKHU6P4B:1433;instanceName=SQLEXPRESS;DatabaseName=CloudAppDb;user=Elba1;password=elba1");
        return conn;
    }

    catch(Exception e){
    JOptionPane.showMessageDialog(null, e);
    return null;
}
}
    
}
    