/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cloud.app;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author ELBA
 */
public class DBMasterConnection {
    
    
    public static Connection connect() throws ClassNotFoundException{ 

    Connection conn =null; 
    
    try{

    Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            conn = DriverManager.getConnection("jdbc:sqlserver://LAPTOP-AKHU6P4B:1433;instanceName=SQLEXPRESS;DatabaseName=AssignmentCloud;user=Elba1;password=elba1");

    System.out.println("Connection is successfull");

    }

    catch(SQLException e){

     System.out.println(e);

    }
        return conn;
    }
    
}
