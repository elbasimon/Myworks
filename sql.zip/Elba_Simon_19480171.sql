--1.1

SET SERVEROUTPUT ON;
SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q1.1.csv';

DECLARE
CURSOR sales_cursor IS

SELECT customers.c_id,c_fname,c_lname,c_address3,sp_total,vehicles.v_regno,v_make,v_model,c_colour 
FROM customers,vehicles,sales_purchases,lu_colours
WHERE customers.c_id = sales_purchases.c_id
AND sales_purchases.v_regno = vehicles.v_regno
AND sales_purchases.c_id = lu_colours.c_no;

c_row sales_cursor%ROWTYPE;

BEGIN

DBMS_OUTPUT.PUT_LINE('Customer ID'|| ',' ||'Customer First Name'|| ',' ||'Customer Last Name'|| ',' ||'Customer City'|| ',' ||'Sales Total'|| ',' ||'Vehicle Regno'|| ',' ||'Vehicle Make'|| ',' ||'Vehicle Model'|| ',' ||'Vehicle Colour');
	
    FOR c_row IN sales_cursor LOOP
    
		DBMS_OUTPUT.PUT_LINE(
            c_row.c_id || ',' ||
            c_row.c_fname || ',' ||
            c_row.c_lname || ',' ||
            c_row.c_address3 || ',' ||
            c_row.sp_total || ',' ||
            c_row.v_regno || ',' ||
            c_row.v_make || ',' ||
            c_row.v_model || ',' ||
            c_row.c_colour );
            
	END LOOP;
END;
/


--1.2

SET SERVEROUTPUT ON;
SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q1.2.csv';

DECLARE
CURSOR sales_cursor IS

SELECT customers.c_id,c_fname,c_lname,c_ph,sp_invoice,vehicles.v_regno,v_make,v_model,sales_persons.sp_id,sp_fname,sp_sup 
FROM customers,vehicles,sales_purchases,sales_persons
WHERE customers.c_id = sales_purchases.c_id
AND sales_purchases.v_regno = vehicles.v_regno
AND sales_purchases.sp_id = sales_persons.sp_id;

c_row sales_cursor%ROWTYPE;

BEGIN

DBMS_OUTPUT.PUT_LINE('Customer ID'|| ',' ||'Customer First Name'|| ',' ||'Customer Last Name'|| ',' ||'Customer Phone'|| ',' ||'Sales Invoice'|| ',' ||'Vehicle Regno'|| ',' ||'Vehicle Make'|| ',' ||'Vehicle Model'|| ',' ||'Vehicle Year'|| ',' ||'Salesperson ID'|| ',' ||'Sales Persons Name'|| ',' ||'Supervisor');
	
    FOR c_row IN sales_cursor LOOP
    
		DBMS_OUTPUT.PUT_LINE(
            c_row.c_id || ',' ||
            c_row.c_fname || ',' ||
            c_row.c_lname || ',' ||
            c_row.c_ph || ',' ||
            c_row.sp_invoice || ',' ||
            c_row.v_regno || ',' ||
            c_row.v_make || ',' ||
            c_row.v_model || ',' ||
            c_row.sp_id || ',' ||
            c_row.sp_fname || ',' ||
            c_row.sp_sup);
            
	END LOOP;
END;
/

--2.1

CREATE OR REPLACE PROCEDURE SaleByMake(vmake IN VARCHAR)
IS
CURSOR veh_cursor IS
SELECT v.v_regno,v.v_make,v.v_model,v.v_year,v.v_numowners,v.v_price,c.c_colour FROM vehicles v JOIN lu_colours c ON v.c_no = c.c_no
WHERE v.v_make = vmake;

veh_row  veh_cursor%rowtype;
Result VARCHAR(200);
BEGIN
   
   DBMS_OUTPUT.PUT_LINE('REG NUMBER' || ',' || 'MAKE' || ',' ||  'MODEL' ||  ',' || 'YEAR'|| ',' || 'NUMBER OF OWNERS'|| ',' || 'PRICE' || ',' ||'COLOUR');
   FOR veh_row IN veh_cursor LOOP
   Result := veh_row .v_regno || ',' || veh_row .v_make || ',' ||  veh_row .v_model  || ',' ||veh_row .v_year || ',' ||  veh_row .v_numowners || ',' || veh_row .v_price
             || ',' ||veh_row .c_colour;
   DBMS_OUTPUT.PUT_LINE(Result);
   END LOOP;
EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q2.1.1.csv';
ACCEPT MAKE CHAR PROMPT 'Enter the make of vehicle: ';
EXECUTE SALEBYMAKE('&MAKE');

--

CREATE OR REPLACE PROCEDURE SaleByMake(vmodel IN VARCHAR)
IS
CURSOR vh_cursor IS
SELECT v.v_regno,v.v_make,v.v_model,v.v_year,v.v_numowners,v.v_price,c.c_colour FROM vehicles v JOIN lu_colours c ON v.c_no = c.c_no 
WHERE v.v_model = vmodel;

vh_row  vh_cursor%rowtype;
Result VARCHAR(200);
BEGIN
   
   DBMS_OUTPUT.PUT_LINE('REG NUMBER' || ',' || 'MAKE' || ',' ||  'MODEL' ||  ',' || 'YEAR'|| ',' || 'NUMBER OF OWNERS'|| ',' || 'PRICE' || ',' ||'COLOUR');
   FOR vh_row IN vh_cursor LOOP
   Result := vh_row .v_regno || ',' || vh_row .v_make || ',' ||  vh_row .v_model  || ',' ||vh_row .v_year || ',' ||  vh_row .v_numowners || ',' || vh_row .v_price
             || ',' ||vh_row .c_colour;
   DBMS_OUTPUT.PUT_LINE(Result);
   END LOOP;
EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q2.1.2.csv';
ACCEPT VEHMODEL CHAR PROMPT 'Enter the model of vehicle: ';
EXECUTE SALEBYMAKE('&VEHMODEL');

--2.2

SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE SalesReport(startdate IN VARCHAR,enddate IN VARCHAR)
IS
CURSOR year_cursor IS
SELECT sp_invoice,sp_datesold,sp_total,sp_id,v_regno FROM sales_purchases 
WHERE sp_datesold BETWEEN startdate AND enddate;
 
year_row  year_cursor%rowtype;
Result VARCHAR(200);
BEGIN
   
   DBMS_OUTPUT.PUT_LINE('INVOICE NUMBER' || ',' || 'DATE SOLD' || ',' ||  'TOTAL' ||  ',' || 'SALESPERSON ID'|| ',' || 'REGNO');
   FOR year_row IN year_cursor LOOP
   Result := year_row.sp_invoice || ',' || year_row.sp_datesold || ',' ||  year_row.sp_total  || ',' ||year_row.sp_id  || ',' ||year_row.V_REGNO;
   DBMS_OUTPUT.PUT_LINE(Result);
   END LOOP;
EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q2.2.csv';
ACCEPT startdate DATE PROMPT 'Enter the start date you want to search for: ';
ACCEPT enddate DATE PROMPT 'Enter the end date you want to search for: ';
EXECUTE SalesReport('&startdate','&enddate');

--2.3

SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE searchcid(cid IN NUMBER) 
IS
CURSOR search_cursor IS

SELECT sp.sp_invoice,sp.sp_datesold,sp.sp_total,c.c_fname,c.c_lname,
v.v_regno,v.v_make,v.v_model,v.v_year,v.v_numowners,v.v_price,v.v_miledge,sp.sp_id 
FROM sales_purchases sp JOIN customers c ON sp.c_id = c.c_id JOIN vehicles V ON sp.v_regno = v.v_regno
WHERE sp.c_id = cid;
 
search_row  search_cursor%rowtype;
Result VARCHAR(200);
BEGIN
   
   DBMS_OUTPUT.PUT_LINE('INVOICE NUMBER' || ',' || 'DATE SOLD' || ',' ||  'TOTAL' ||  ',' || 'CUSTOMER NAME'|| ',' || 'REGNO' || ',' || 
   'MAKE' || ',' ||  'MODEL' ||  ',' || 'YEAR'|| ',' || 'NUMBER OF OWNERS'|| ',' || 'PRICE' || ',' || 'MILEAGE'|| ',' || 'SALESPERSON ID');
   
   FOR search_row IN search_cursor LOOP
   Result := search_row.sp_invoice || ',' || search_row.sp_datesold || ',' ||  search_row.sp_total  || ',' ||search_row.c_fname || ' ' ||  search_row.c_lname || ',' || search_row.v_regno
             || ',' ||search_row.v_make|| ',' ||search_row.v_model || ',' ||search_row.v_year || ',' ||search_row.v_numowners || ',' ||search_row.v_price
             || ',' ||search_row.v_miledge || ',' ||search_row.sp_id;
   DBMS_OUTPUT.PUT_LINE(Result);
   END LOOP;
EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q2.3.1.csv';
ACCEPT CID NUMBER PROMPT 'Enter the customer id: ';
EXECUTE searchcid(&CID);


CREATE OR REPLACE PROCEDURE searchlastname(lastname IN VARCHAR)
IS
CURSOR search_cursor IS
SELECT sp.sp_invoice,sp.sp_datesold,sp.sp_total,c.c_fname,c.c_lname,
v.v_regno,v.v_make,v.v_model,v.v_year,v.v_numowners,v.v_price,v.v_miledge,sp.sp_id 
FROM sales_purchases sp JOIN customers c ON sp.c_id = c.c_id JOIN vehicles V ON sp.v_regno = v.v_regno
WHERE c.c_lname = lastname;

search_row  search_cursor%rowtype;
Result VARCHAR(200);
BEGIN
   
   DBMS_OUTPUT.PUT_LINE('INVOICE NUMBER' || ',' || 'DATE SOLD' || ',' ||  'TOTAL' ||  ',' || 'CUSTOMER NAME'|| ',' || 'REGNO' || ',' || 
   'MAKE' || ',' ||  'MODEL' ||  ',' || 'YEAR'|| ',' || 'NUMBER OF OWNERS'|| ',' || 'PRICE' || ',' || 'MILEAGE'|| ',' || 'SALESPERSON ID');
   
   FOR search_row IN search_cursor LOOP
   Result := search_row.sp_invoice || ',' || search_row.sp_datesold || ',' ||  search_row.sp_total  || ',' ||search_row.c_fname || ' ' ||  search_row.c_lname || ',' || search_row.v_regno
             || ',' ||search_row.v_make|| ',' ||search_row.v_model || ',' ||search_row.v_year || ',' ||search_row.v_numowners || ',' ||search_row.v_price
             || ',' ||search_row.v_miledge || ',' ||search_row.sp_id;
   DBMS_OUTPUT.PUT_LINE(Result);
   END LOOP;
EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q2.3.2.csv';
ACCEPT LASTNAME CHAR PROMPT 'Enter the customer last name: ';
EXECUTE searchlastname('&LASTNAME');

--2.4

SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE paypro(startdate IN VARCHAR,enddate IN VARCHAR)
IS
CURSOR pay_cursor IS
SELECT p.p_invoice,p.p_date,p.p_amount,c.c_id,c.c_fname,c.c_lname,p.sp_invoice FROM 
payments p,customers c 
WHERE p.c_id = c.c_id AND
p.p_date BETWEEN startdate AND enddate;

pay_row  pay_cursor%rowtype;
Result VARCHAR(200);
BEGIN
   
   DBMS_OUTPUT.PUT_LINE('INVOICE NUMBER' || ',' || 'PAYMENT DATE' || ',' ||  'PAYMENT AMOUNT' ||  ',' || 'CUSTOMER ID'|| ',' || 'NAME'|| ',' || 'SALES PURCHASE INVOICE NUMBER');
   FOR pay_row IN pay_cursor LOOP
   Result := pay_row.p_invoice || ',' || pay_row.p_date|| ',' ||  pay_row.p_amount  || ',' ||pay_row.c_id || ',' ||  pay_row.c_fname || ' ' || pay_row.c_lname
             || ',' ||pay_row.sp_invoice;
   DBMS_OUTPUT.PUT_LINE(Result);
   END LOOP;
EXCEPTION
WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q2.4.csv';
ACCEPT STARTDATE DATE PROMPT 'Enter start date: ';
ACCEPT ENDDATE DATE PROMPT 'Enter end date: ';
EXECUTE paypro('&STARTDATE','&ENDDATE');

--3.1

CREATE OR REPLACE FUNCTION NumberOfDays (
	startdate IN DATE,enddate IN DATE
) RETURN NUMBER
IS
	noofdays NUMBER;
BEGIN
	noofdays := TRUNC (enddate - startdate);
	RETURN noofdays;
EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE(SQLERRM);
END;
/

--3.2

CREATE OR REPLACE PROCEDURE days_pro
IS
	CURSOR days_cursor IS
		SELECT o_id, o_date, o_totalqty,o_total FROM orders;
	days_row days_cursor%rowtype;	
BEGIN
    DBMS_OUTPUT.PUT_LINE('ORDER ID'|| ',' ||'ORDER DATE'|| ',' ||'TOTAL QTY'|| ',' ||'TOTAL'||  ',' ||'NO. OF DAYS');
	FOR days_row IN days_cursor LOOP
		DBMS_OUTPUT.PUT_LINE(
            days_row.o_id || ',' ||
            days_row.o_date || ',' ||
            days_row.o_totalqty || ',' ||
            days_row.o_total || ',' ||
            NumberOfDays(days_row.o_date,TO_CHAR(SYSDATE,'DD/MM/YYYY')));
	END LOOP;
END;
/


SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q3.2.csv';
EXECUTE days_pro;

--4.1

SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE AddPurchaseSale(in_datesold in varchar,in_deposit in NUMBER,in_sp_id in varchar,in_c_id in Number,in_v_regno in varchar)
IS
BEGIN
INSERT INTO sales_purchases(sp_datesold,sp_saleprice,sp_deposit,sp_id,c_id,v_regno) SELECT TO_DATE(in_datesold,'dd-mm-yyyy'), vehicles.v_price,in_deposit,in_sp_id, in_c_id,in_v_regno FROM vehicles WHERE vehicles.v_regno = in_v_regno;
UPDATE sales_purchases SET sp_addncost = sp_saleprice*0.2;
UPDATE sales_purchases SET sp_total = (sp_saleprice + sp_addncost) - in_deposit;
COMMIT;
EXCEPTION
WHEN OTHERS THEN
    ROLLBACK;
END;
/

SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q4.1.csv';
ACCEPT datesold date PROMPT 'Enter the Date Sold: ';
ACCEPT deposit number PROMPT 'Enter the Deposit: ';
ACCEPT salesPersonId char PROMPT 'Enter the Sales Person Id: ';
ACCEPT customerId number PROMPT 'Enter the Customer Id: ';
ACCEPT regNo char PROMPT 'Enter the RegNo. of Vehicle: ';
EXECUTE AddPurchaseSale('&datesold',&deposit,'&salesPersonId',&customerId,'&regNo');

--Testing--
-- 4.1.5.1
SELECT * FROM SALES_PURCHASES;
--4.1.5.4 
ROLLBACK;


--4.2

SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE AddPurchaseOrderItem(in_orderid in NUMBER,in_itemno in number,in_qty in Number)
IS
BEGIN
INSERT INTO order_lines (o_id, i_no, i_make, i_model, i_price, i_year, ol_qty) 
SELECT in_orderid, in_itemno, items.i_make, items.i_model, items.i_price, items.i_year,in_qty FROM items WHERE items.i_no = in_itemno;
UPDATE order_lines SET ol_subtotal = ol_qty * i_price;
UPDATE orders SET o_total = (
	SELECT SUM (ol_subtotal)
	FROM order_lines
	WHERE orders.o_id = order_lines.o_id );
    UPDATE orders SET o_totalqty = (
	SELECT SUM (ol_qty)
	FROM order_lines
	WHERE orders.o_id = order_lines.o_id );
COMMIT;
EXCEPTION
WHEN OTHERS THEN
    ROLLBACK;
END;
/

SET SERVEROUTPUT ON;
CREATE OR REPLACE PROCEDURE AddPurchaseSale(in_datesold in varchar,in_deposit in NUMBER,in_sp_id in varchar,in_c_id in Number,in_v_regno in varchar)
IS
BEGIN
INSERT INTO sales_purchases(sp_datesold,sp_saleprice,sp_deposit,sp_id,c_id,v_regno) SELECT TO_DATE(in_datesold,'dd-mm-yyyy'), vehicles.v_price,in_deposit,in_sp_id, in_c_id,in_v_regno FROM vehicles WHERE vehicles.v_regno = in_v_regno;
UPDATE sales_purchases SET sp_addncost = sp_saleprice*0.2;
UPDATE sales_purchases SET sp_total = (sp_saleprice + sp_addncost) - in_deposit;
COMMIT;
EXCEPTION
WHEN OTHERS THEN
    ROLLBACK;
END;
/

SPOOL 'C:\Users\ELBA\Desktop\Assignment\Q4.2.csv';
ACCEPT datesold date PROMPT 'Enter the Date Sold: ';
ACCEPT deposit number PROMPT 'Enter the Deposit: ';
ACCEPT salesPersonId char PROMPT 'Enter the Sales Person Id: ';
ACCEPT customerId number PROMPT 'Enter the Customer Id: ';
ACCEPT regNo char PROMPT 'Enter the RegNo. of Vehicle: ';
EXECUTE AddPurchaseSale('&datesold',&deposit,'&salesPersonId',&customerId,'&regNo');
ACCEPT orderID number PROMPT 'Enter the order ID: ';
ACCEPT itemNo number PROMPT 'Enter the Item Number: ';
ACCEPT qty number PROMPT 'Enter the Quantity: ';
EXECUTE AddPurchaseOrderItem(&orderID,&itemNo,&qty);

--Testing--

INSERT INTO orders (o_date, s_code, sp_id) VALUES (TO_DATE('08-Oct-2018','dd-mm-yyyy'),'XTRQC','MK201');
SELECT * FROM ORDER_LINES;
ROLLBACK;

--5

SET SERVEROUTPUT ON;
CREATE OR REPLACE TRIGGER sup_check
BEFORE INSERT OR UPDATE OF sp_sup
ON sales_persons
FOR EACH ROW

DECLARE
num_of_staff NUMBER;

BEGIN
SELECT COUNT(sp_sup) INTO num_of_staff
FROM sales_persons
WHERE sp_sup = :NEW.sp_sup;

IF(num_of_staff > 2) THEN
RAISE_APPLICATION_ERROR(-20000,'INSERT DENIED: Staff allocated too many');
END IF;

CASE
WHEN INSERTING THEN 
DBMS_OUTPUT.PUT_LINE('INSERTING SUPERVISOR ID:' || :NEW.sp_id);

WHEN UPDATING ('SP_SUP') THEN
DBMS_OUTPUT.PUT_LINE('UPDATING SUPERVISOR FOR RECORD ID:' || :OLD.sp_id);
DBMS_OUTPUT.PUT_LINE('OLD SUPERVISOR ID:' ||:OLD.sp_sup);
DBMS_OUTPUT.PUT_LINE('NEW SUPERVISOR ID:' ||:NEW.sp_sup);

END CASE;

EXCEPTION
WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE(SQLERRM);

END sup_check;
/

ALTER TRIGGER sup_check ENABLE;

INSERT INTO sales_persons VALUES ('EP02', 'ELBA', 'SIMON', '08-Oct-15', '022087965', 0.15, 'MK201');
UPDATE sales_persons SET SP_SUP = 'PG634' WHERE SP_ID = 'BP301';
ROLLBACK;