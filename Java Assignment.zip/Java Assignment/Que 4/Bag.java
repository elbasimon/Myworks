package que4;

public class Bag {

	private String colour;
	private double volume;

	public Bag(String colour, double volume) {
		setColour(colour);
		setVolume(volume);
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

	public double getVolume() {
		return volume;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

}
