package que4;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static void main(String[] args) {

		List<Bag> bags = new LinkedList<>();

		bags.add(new Bag("Red",12.5));
		bags.add(new Bag("Green",45.8));
		bags.add(new Bag("Blue",15.9));
		BagApp bgapp = new BagApp();

		double totalVolume = bgapp.calcTotalVolume(bags, 0);

		System.out.printf("Total number of bags %d\n", bags.size());
		System.out.printf("Total volume: %.2f\n", totalVolume);
	}

}
