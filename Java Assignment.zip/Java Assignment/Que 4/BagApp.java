package que4;
import java.util.List;

public class BagApp {
	
	public static double calcTotalVolume(List<Bag> bagList, double accum) {
		if(bagList != null && bagList.size() > 0) {
			Bag t = bagList.get(0);
			accum += t.getVolume();
			List<Bag> sublist = bagList.subList(1,bagList.size());
			return calcTotalVolume(sublist, accum);

		}else {
			return accum;
		}

	}

}
