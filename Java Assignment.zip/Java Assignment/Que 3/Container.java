package asignment2;

public class Container {
	
private String colour;
	
	public Container(String colour) {
		this.setColour(colour);
	}
	
	public String getContainerType() {
		return "I'm a container";
	}

	public String getColour() {
		return colour;
	}

	public void setColour(String colour) {
		this.colour = colour;
	}

}
