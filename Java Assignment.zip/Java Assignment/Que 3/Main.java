package asignment2;

import java.util.LinkedList;
import java.util.List;

public class Main {
	
	public static void main(String[] args) {

		List<Container> containers = new LinkedList<>();
		containers.add(new Container("red"));
		containers.add(new Box(4, 3, 2,"white"));
		containers.add(new Box(5, 13, 8,"black"));
		containers.add(new Container("orange"));
		displayContainerTypes(containers); //produces output part 1
		Box[] boxArray1 = {
				new Box(4, 3, 2,"white"),
				new Box(9, 5, 6,"red"),
				new Box(3, 6, 12,"purple"),
				new Box(15, 10, 4,"orange"),
				new Box(4, 14, 10,"black"),
		};
		Box[] boxArray2 = {
				new Box(3, 4, 2,"pink"),
				new Box(10, 2, 4,"red"),
				new Box(8, 5, 7,"white"),
				new Box(14, 4, 10,"blue"),
				new Box(10, 15, 4,"bindle"),
		};
		//produces output part 2
		countOverlapBoxes(boxArray1, boxArray2);
	}
	private static void countOverlapBoxes(Box[] boxArray1, Box[] boxArray2) {
		if(boxArray1 == null || boxArray1.length == 0 || boxArray2 == null || boxArray2.length == 0) {
			return;
		}
		int colourlap = 0;
		int volumelap = 0;

		for(Box b1 : boxArray1) {
			for(Box b2 : boxArray2) {
				if(b1.getColour().equalsIgnoreCase(b2.getColour())) {
					colourlap ++;
				}

				if(b1.getVolume() == b2.getVolume()) {
					volumelap ++;
				}
			}
		}
		System.out.printf("There are %d Box objects with overlapping colour between the two arrays\n", colourlap);
		System.out.printf("There are %d Box objects with overlapping colour between the two arrays\n", volumelap);

	}
	public static void displayContainerTypes(List<Container> containers){ 

		if(containers == null || containers.size() == 0) {
			return;
		}

		for(Container conn : containers) {

			System.out.println(conn.getContainerType());

		}
	}
	
	

}
