package asignment2;

public class Box extends Container {
	
	private double height;
	private double width;
	private double length;
	
	public Box(double height,double width, double length,String colour) {
		super(colour);
		this.setHeight(height);
		this.setWidth(width);
		this.setLength(length);
		
	}
	
	@Override 
	public String getContainerType() {
		return "I'm a box";
	}
	
	public double getVolume() {
		return height * width * length;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getLength() {
		return length;
	}
	public void setLength(double length) {
		this.length = length;
	}

}
