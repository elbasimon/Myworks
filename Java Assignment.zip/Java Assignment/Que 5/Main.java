package que5;
import java.io.IOException;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		String txtfile = "data/data.txt";
		try {
			ScoreApp scoreapp = new ScoreApp(txtfile);
			scoreapp.printAll();
			System.out.println();
			System.out.printf("Lowest score: %.2f\n", scoreapp.getMinScore());
			System.out.printf("Top student ID: %s\n", scoreapp.getTopStudentID());
			System.out.printf("Scores between 50-80: %d\n", scoreapp.countScoreRange());
			double total = recursiveTotalScore(scoreapp.getStudents(), 0);
			System.out.printf("Total scores: %.2f\n", total);
		}catch(IOException ioe) {
			System.out.printf("Perhaps missing text file: %s/%s? \n\n",
					new Main().getClass().getPackage().getName(), txtfile);
		}


	}

	private static double recursiveTotalScore(List<Student> students, double accum) {
		if(students != null && students.size() > 0) {
			double score = students.get(0).getScore(); // setting score with 0th position 
			accum += score; //performing addition
			List<Student> stList = students.subList(1, students.size()); //creating sublist with 1st position to last
			return recursiveTotalScore(stList,accum);
		}
		else {
			return accum;
		}	
	}


}
