package que5;

public class Student {

	private String ID;
	private double score;

	public Student(String ID,double score) {

		this.setID(ID);
		this.setScore(score);
	}

	public void displayStudent() {
		System.out.println("Info about Student: ");
		System.out.printf("%-20s%-20s\n", "ID", getID());
		System.out.printf("%-20s%-20.2f\n", "Score", getScore());
	}


	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

}
