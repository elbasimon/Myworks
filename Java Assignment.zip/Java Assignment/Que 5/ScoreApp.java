package que5;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;

public class ScoreApp {

	private List<Student> students;
	public List<Student> getStudents() {
		return students;
	}

	public ScoreApp(String filename) throws IOException {
		students = new LinkedList<>();
		readData(filename);
	}

	public void readData(String filename) throws IOException {
		students = new LinkedList<>();
		Path path = new File(filename).toPath();
		List<String> lines = Files.readAllLines(path); // to read file
		for(String line : lines) {
			String[] items = line.split(",");
			String id = items[0];
			double score = Double.parseDouble(items[1]);
			Student s = new Student(id, score);
			students.add(s);
		}
	}

	public void printAll() {
		if(students != null && students.size() > 0) {
			System.out.printf("%-20s%-20s\n", "ID", "Score");
			for(Student s : students) {
				System.out.printf("%-20s%-20s\n", s.getID(),s.getScore());
			}
		}
	}

	public double getMinScore() {
		if(students == null || students.size() == 0) {
			System.out.println("No Students in List");
			return 0;
		}
		double minScore = students.get(0).getScore(); //getting the first score and setting it as min score
		for(Student stu :students) {
			if(minScore > stu.getScore()) {
				minScore = stu.getScore();
			}
		}
		return minScore;
	}
	public int countScoreRange() {
		if(students == null || students.size() == 0) {
			System.out.println("No Students in List");
			return 0;
		}
		int count = 0;
		for(Student stu :students) {
			if(stu.getScore() >= 50 && stu.getScore() <= 80) {
				count++;
			}
		}
		return count;

	}
	public String getTopStudentID() {

		if(students == null || students.size() == 0) {
			return "No Students in List";
		}
		double maxScore = students.get(0).getScore();
		String id = students.get(0).getID();//to get id of the initial maxscore student 
		for(Student stu :students) {
			if(stu.getScore() > maxScore) {
				maxScore = stu.getScore();
				id = stu.getID();
			}
		}
		return id;
	}


}
