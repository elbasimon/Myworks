package que2;

public class Main {
	
public static void main(String[] args) {
		
		Card hand[] = {
				 new Card("Spade", 3),
				 new Card("Club", 10),
				 new Card("Diamond", 11),
				 new Card("Heart", 9),
				 new Card("Diamond", 13),
				 };
				 processHand(hand);
				 }
				 public static void processHand(Card[] hand) {
					 
					 int total = 0;
					 if((hand.length == 0) || (hand == null)) {
						 return;
					 }
					 else {
						 for(Card c : hand) {
							 c.displayCard();
							 total += c.getFaceValue();
						 }
						 
						System.out.printf("Total face values of hand: %d points",total);
					 }
					 
	}

}
