package que2;

public class Card {
	
	private String suit;
	private int faceValue;
	
	public Card(String suit,int faceValue) {
		setFaceValue(faceValue);
		setSuit(suit);
	
}

	public String getSuit() {
		return suit;
	}

	public void setSuit(String suit) {
		this.suit = suit;
	}

	public int getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(int faceValue) {
		this.faceValue = faceValue;
	}
	
	public void displayCard() {
		System.out.printf("The card is %s %d\n", suit,faceValue);
	}

}
